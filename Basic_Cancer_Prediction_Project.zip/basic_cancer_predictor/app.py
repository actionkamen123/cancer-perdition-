
from flask import Flask, render_template, request
import numpy as np
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)

# Simple dummy training data
# Features: [age, bmi, smoking]
X = np.array([
    [25, 22, 0],
    [45, 30, 1],
    [50, 28, 1],
    [35, 24, 0],
    [60, 32, 1],
    [40, 26, 0]
])

y = np.array([0, 1, 1, 0, 1, 0])  # 0 = Low risk, 1 = High risk

model = LogisticRegression()
model.fit(X, y)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        age = int(request.form["age"])
        bmi = float(request.form["bmi"])
        smoking = int(request.form["smoking"])

        prediction = model.predict([[age, bmi, smoking]])[0]
        result = "HIGH Cancer Risk" if prediction == 1 else "LOW Cancer Risk"

    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
